package entities;

// GeneralCustomer class
public class GeneralCustomer extends Customer {

	public GeneralCustomer(String customerCode, String type, Person primaryContact, String name, Address address) {
		super(customerCode, type, primaryContact, name, address);
		// TODO Auto-generated constructor stub
	}

}
