package driver;

public class Database {
	
	//credentials of the user, and inclusion of all other information needed to set up a connection to the database
	public static final String DRIVER_CLASS = "com.mysql.jdbc.Driver";	
	public static final String url = "jdbc:mysql://cse.unl.edu/kpagilla";
	public static final String username = "kpagilla";
	public static final String password = "TwC8zq";

}
